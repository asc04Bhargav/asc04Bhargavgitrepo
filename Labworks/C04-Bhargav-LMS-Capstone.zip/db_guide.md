- Create database LMSDB
- create table login.
- title of project should.
C4-Bhargav-LMS-Frontend-Capstone-Project-sln
C4-Bhargav-LMS-Backend-Capstone-Project-sln
