import { Component } from '@angular/core';

@Component({
  selector: 'app-acquisition',
  templateUrl: './acquisition.component.html',
  styleUrl: './acquisition.component.css'
})
export class AcquisitionComponent {

}
