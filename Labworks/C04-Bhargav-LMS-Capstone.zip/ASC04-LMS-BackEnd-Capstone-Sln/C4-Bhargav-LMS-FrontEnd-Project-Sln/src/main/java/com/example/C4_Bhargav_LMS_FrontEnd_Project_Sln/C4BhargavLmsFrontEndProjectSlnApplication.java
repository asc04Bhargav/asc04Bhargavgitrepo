package com.example.C4_Bhargav_LMS_FrontEnd_Project_Sln;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C4BhargavLmsFrontEndProjectSlnApplication {

	public static void main(String[] args) {
		System.out.println("Just another Java App, not any more!");
		SpringApplication.run(C4BhargavLmsFrontEndProjectSlnApplication.class, args);
	}

}
