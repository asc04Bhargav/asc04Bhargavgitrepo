package com.example.C4_Bhargav_LMS_FrontEnd_Project_Sln;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C4BhargavLmsFrontEndProjectSlnApplicationTests {

	@Test
	void contextLoads() {
	}

}
